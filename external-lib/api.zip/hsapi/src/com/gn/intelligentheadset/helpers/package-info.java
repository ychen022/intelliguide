/**
 * Helper classes to facilitate your work.
 *
 */

package com.gn.intelligentheadset.helpers;
