package com.gn.intelligentheadset.helpers;

import java.util.List;

import android.app.DialogFragment;
import android.app.FragmentManager;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.gn.intelligentheadset.IHSDeviceDescriptor;
import com.gn.intelligentheadset.hsapi.R;

/**
 * Shows list of devices. Lets the user select one or cancel selection.
 * <p>
 * Can probably also be used as a non-dialog fragment.
 */
public class IHSDeviceListFragment extends DialogFragment {

    public static final String        fragmentTag = "devlist"; // must be unique
    private DeviceListAdapter         mDevicesAdapter;
    private Button                    btnCancel;
    private ListView                  lvDevices;
    private boolean                   mIsDialog;
    private DeviceSelectionListener   mListener;
    private List<IHSDeviceDescriptor> mList       = null;

    /**
     * Callback that receives info on user action.
     */
    public interface DeviceSelectionListener {
        /**
         * The user has selected a device
         * 
         * @param dev
         *            The selected device
         */
        public void onDeviceSelected(IHSDeviceDescriptor dev);

        /**
         * The user has dismissed the dialog
         */
        public void onDialogDismissed();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true); // need to ensure that our fields stay alive
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_discovery, null);
        mIsDialog = getDialog() != null;
        if (mIsDialog)
            getDialog().setTitle(R.string.select_headset);

        ProgressBar pbProgress = (ProgressBar) v.findViewById(R.id.pb1);
        pbProgress.setVisibility(View.INVISIBLE);

        btnCancel = (Button) v.findViewById(R.id.btnCancel);
        lvDevices = (ListView) v.findViewById(R.id.lvDevices);
        mDevicesAdapter = new DeviceListAdapter();
        lvDevices.setAdapter(mDevicesAdapter);

        btnCancel.setVisibility(mIsDialog ? View.VISIBLE : View.GONE);

        btnCancel.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if (mListener != null)
                    mListener.onDeviceSelected(null);
                dismiss();
            }
        });

        lvDevices.setOnItemClickListener(new OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int pos, long arg3) {
                if (mListener != null)
                    mListener.onDeviceSelected(mDevicesAdapter.mList.get(pos));
                if (mIsDialog)
                    dismiss();
            }
        });

        mDevicesAdapter.setList(mList);
        return v;
    }

    /**
     * Hack to let DialogFragment with setRetainInstance(true) survive a screen rotation (or other config change).
     * See https://code.google.com/p/android/issues/detail?id=17423
     */
    @Override
    public void onDestroyView() {
        if (getDialog() != null && getRetainInstance())
            getDialog().setDismissMessage(null);
        super.onDestroyView();
    }

    @Override
    public void onDismiss(DialogInterface dialog) {
        super.onDismiss(dialog);
        if (mListener != null)
            mListener.onDialogDismissed();
    }

    /**
     * Show the dialog.
     * 
     * @param manager
     *            Obtained from the calling Context.
     * @param list
     *            The list of devices to show.
     * @param listener
     *            Callback that receives info on user action.
     */
    public void show(FragmentManager manager, List<IHSDeviceDescriptor> list, DeviceSelectionListener listener) {
        super.show(manager, fragmentTag);
        mListener = listener;
        mList = list;
    }

    /**
     * Update the list of devices (can be used while the dialog is displayed)
     * 
     * @param list
     *            Updated list of devices.
     */
    public void updateList(List<IHSDeviceDescriptor> list) {
        mList = list;
        if (mDevicesAdapter != null)
            mDevicesAdapter.setList(mList);
    }

    // Feed discovered devices to the UI
    private class DeviceListAdapter extends BaseAdapter {

        private List<IHSDeviceDescriptor> mList;

        public void setList(List<IHSDeviceDescriptor> list) {
            mList = list;
            notifyDataSetChanged();
        }

        @Override
        public int getCount() {
            return mList == null ? 0 : mList.size();
        }

        @Override
        public Object getItem(int pos) {
            return pos;
        }

        @Override
        public long getItemId(int pos) {
            return pos;
        }

        @Override
        public View getView(int pos, View v, ViewGroup parent) {
            if (v == null) {
                v = getActivity().getLayoutInflater().inflate(R.layout.discovered_device_item, null);
            }
            TextView tvName = (TextView) v.findViewById(R.id.tvName);
            TextView tvRSSI = (TextView) v.findViewById(R.id.tvRSSI);

            tvName.setText(mList.get(pos).getName());
            tvRSSI.setVisibility(View.INVISIBLE);
            return v;
        }

    }
}
