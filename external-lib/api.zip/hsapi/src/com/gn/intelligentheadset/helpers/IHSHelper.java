package com.gn.intelligentheadset.helpers;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

import com.gn.intelligentheadset.IHSDevice.IHSDeviceConnectionState;

/**
 * Contains app-level convenience helpers.
 * 
 * As they may be application-specific, such helpers are not officially part of the IHS API. Feel free to modify.
 */
public class IHSHelper {

    /**
     * Get a suitable String thet represents the connection state.
     * <p>
     * Alternatively, you can simply use {@link IHSDeviceConnectionState#name()}.
     * 
     * @param connectionState
     *            The state.
     * @return A corresponding string.
     */
    public static String getConnectionStateString(IHSDeviceConnectionState connectionState) {
        switch (connectionState) {
            case IHSDeviceConnectionStateBluetoothOn:
                return "Bluetooth ON";
            case IHSDeviceConnectionStateBluetoothOff:
                return "Bluetooth OFF";
            case IHSDeviceConnectionStateConnected:
                return "Connected";
            case IHSDeviceConnectionStateConnecting:
                return "Connecting";
            case IHSDeviceConnectionStateConnectionFailed:
                return "Failed";
            case IHSDeviceConnectionStateDisconnected:
                return "Disconnected";
            case IHSDeviceConnectionStateDiscovering:
                return "Discovering";
            case IHSDeviceConnectionStateLingering:
                return "Lingering";
            case IHSDeviceConnectionStateNone:
                return "Idle";
            case IHSDeviceConnectionStateConnectionTakesTooLong:
                return "Unresponsive";
            case IHSDeviceConnectionStateDeviceNotFound:
                return "Device not found";
        }
        return "??";
    }

    /**
     * Show an alert dialog with the specified string resource.
     * 
     * @param c
     *            The calling context.
     * @param stringId
     *            The Message to show.
     */
    public static void showMessage(Context c, int stringId) {
        new AlertDialog.Builder(c).setMessage(stringId).setPositiveButton(android.R.string.ok, new OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        }).show();

    }
}
