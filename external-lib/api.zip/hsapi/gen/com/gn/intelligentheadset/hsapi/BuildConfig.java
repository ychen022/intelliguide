/** Automatically generated file. DO NOT MODIFY */
package com.gn.intelligentheadset.hsapi;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}